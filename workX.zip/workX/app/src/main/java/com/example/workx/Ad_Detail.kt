package com.example.workx

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.workx.R

class Ad_Detail : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ad_detail)
    }
}