# WorkX
Work X is a mobile app code with Kotlin, used to provide a services exchange platform


# Install me
First thing, you have to clone the project 
```shell
git clone https://github.com/vadilkt/WorkX.git
```
# Environnement
You must have Android Studio in your computer. Once clone, you have to sync the gradle to download all the dependencies 
# Workers
- TIEUBEA MOUSSA BORIS EULOGE 21G00797
- TEUMAMMEU KWEKAM VADIL 21G00811
